#include "aula.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void inserir_lista(No **lista){
    No *nova = malloc(sizeof(No));
    if (nova == NULL){
                printf("\n ERRO NA ALOCAÇÂO DE MEMORIA.");
                return;
            }
    printf("Nome: \n");
    fgets(nova->titulo,sizeof(nova->titulo),stdin);
    nova->titulo[strcspn(nova->titulo, "\n")] = '\0';
    printf("Quantidade: \n");
    scanf("%d", &nova -> id);
    nova->proximo = *lista;
    *lista = nova;
    printf("LIVRO ADICIONADO COM SUCESSO.");
}

No *search(No *inicio, int id){
    No *atual = inicio;
    while (atual != NULL)
    {
        if (atual->id == id)
        {
            return atual;
        }
        atual = atual->proximo;
    }
    return NULL;
}

void processar_evento(No *encontrado){

    printf("O que alterar no livro?\n");
    printf("1 ---- RETIRAR ----\n");
    printf("2 ---- RESERVAR ----\n");
    printf("3 ---- CANCELAR RESERVA ----\n");
    printf("4 ---- DEVOLVER ---- \n");
    scanf("%d", &opcao);

    switch(opcao){
        case 1:
            Evento = RETIRAR;
            break;
        case 2:
            Evento = RESERVA;
            break;
        case 3:
            Evento = CANCELAR;
            break;
        case 4:
            Evento = DEVOLVER;
            break;
        default:
            printf("\nValor invalido.");
        break;
    }

}