#ifndef AULA_H
#define AULA_H

typedef enum{
    DISPONIVEL,
    RESERVADO,
    EMPRESTADO

}Estado;

typedef enum{
    RESERVAR,
    RETIRAR,
    CANCELAR,
    DEVOLVER

}Evento;

typedef struct No{
    Estado estado;
    char titulo[100];
    int id;

    struct No *proximo;
}No;

void inserir_lista(No **inicio);
void processar_evento(No **inicio);

#endif